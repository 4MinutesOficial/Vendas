const { ActivityType } = require("discord.js");
const axios = require("axios");
const config = require("../../../config.json");

const statusTexts = [
    "Vendas Automáticas",
    "Planos Baratos",
    "Flash Store"
];

module.exports = {
    name: "ready",
    async execute(client) {
        console.log(`[LOG] ${client.user.username} está pronto!`);

        // Função para atualizar o status
        const updateStatus = () => {
            const randomIndex = Math.floor(Math.random() * statusTexts.length);
            const selectedStatus = statusTexts[randomIndex];
            client.user.setActivity(selectedStatus, {
                type: ActivityType.Playing
            });
        };

        // Atualiza o status inicialmente
        updateStatus();

        // Define o intervalo para mudar o status a cada 10 segundos
        setInterval(updateStatus, 10000);

        // Define o status como idle
        client.user.setStatus("idle");

        // Atualiza a descrição do bot
        const description = `<:antena_bots:1242618642655346749> Bot de vendas Automáticas por mensalidade sem taxas adicionais!\n<:carrinho:1242651646027366452> Bot com preço **BARATO**!\n<:bot3_bots:1242618607951679612> Interessado?\nhttps://discord.gg/fHvnPTas2d`;

        try {
            const response = await axios.patch(`https://discord.com/api/v10/applications/${client.user.id}`, {
                description: description
            }, {
                headers: {
                    "Authorization": `Bot ${config.token}`,
                    "Content-Type": 'application/json',
                }
            });

            console.log("[LOG] Descrição do bot atualizada com sucesso.");
        } catch (error) {
            console.error("[ERROR] Erro ao atualizar descrição do bot:", error.message);
        }
    },
};
